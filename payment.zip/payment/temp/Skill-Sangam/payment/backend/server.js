require('dotenv').config();
const Student = require('./models/Student'); // Adjust path as needed
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const bodyParser = require('body-parser');

const Payment = require('./models/Payment'); // Make sure this file exists

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Route to create a Stripe Checkout session
app.post('/create-checkout-session', async (req, res) => {
  const { amount, studentId, courseId } = req.body;

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: `Course Purchase - ${courseId}`,
          },
          unit_amount: amount * 100,
        },
        quantity: 1,
      }],
      mode: 'payment',
      success_url: 'http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'http://localhost:3000/cancel',
      metadata: { studentId, courseId, amount: amount.toString() },
    });

    res.json({ id: session.id });
  } catch (error) {
    console.error('❌ Error creating session:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// Stripe webhook (must be before express.json)
app.post('/webhook', bodyParser.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('❌ Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const { studentId, courseId, amount } = session.metadata;
    const stripePaymentIntentId = session.payment_intent;

    try {
      const payment = new Payment({
        stripePaymentIntentId,
        status: 'succeeded',
        createdAt: new Date(),
        studentId,
        courseId,
        amount,
      });

      await payment.save();
      console.log("✅ Payment saved to DB:", payment);
    } catch (err) {
      console.error('❌ Failed to save payment:', err);
    }
  }

  res.status(200).end();
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

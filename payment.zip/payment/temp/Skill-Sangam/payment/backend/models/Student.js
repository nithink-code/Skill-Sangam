const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: String,
  email: String,
  // You can add more fields as needed
});

module.exports = mongoose.model('Student', studentSchema);

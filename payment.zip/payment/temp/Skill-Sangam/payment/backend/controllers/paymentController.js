const stripe = require('../utils/stripe');
const Order = require('../models/Order');
const Payment = require('../models/Payment');

// Create payment intent and order record
exports.createPaymentIntent = async (req, res) => {
  try {
    const { studentId, courseId, amount } = req.body;

    // 1. Create order in DB with status 'pending'
    const order = new Order({
      studentId,
      courseId,
      amount,
      paymentStatus: 'pending'
    });
    await order.save();

    // 2. Create Stripe payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // amount in cents
      currency: 'usd',
      metadata: { orderId: order._id.toString() }
    });

    // 3. Create payment record linked to order
    const payment = new Payment({
      orderId: order._id,
      stripePaymentIntentId: paymentIntent.id,
      status: 'pending'
    });
    await payment.save();

    // 4. Return client secret to frontend
    res.status(201).json({
      clientSecret: paymentIntent.client_secret,
      orderId: order._id
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error creating payment intent' });
  }
};

// Webhook to listen to Stripe payment events
exports.stripeWebhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.log(`Webhook signature verification failed.`, err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'payment_intent.succeeded') {
    const paymentIntent = event.data.object;
    const orderId = paymentIntent.metadata.orderId;

    // Update payment and order status
    await Payment.findOneAndUpdate(
      { stripePaymentIntentId: paymentIntent.id },
      { status: 'succeeded' }
    );
    await Order.findByIdAndUpdate(orderId, { paymentStatus: 'paid' });

    // TODO: trigger enrollment, notifications, etc.
  }

  res.json({ received: true });
};

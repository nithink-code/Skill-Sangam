const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const bodyParser = require('body-parser');

// For Stripe webhook, raw body required
router.post('/webhook', bodyParser.raw({ type: 'application/json' }), paymentController.stripeWebhook);

router.post('/create-intent', paymentController.createPaymentIntent);

module.exports = router;

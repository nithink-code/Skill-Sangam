import React, { useState } from "react";
import { loadStripe } from "@stripe/stripe-js";

const stripePromise = loadStripe("pk_test_51RVZyHPpsSqbQQ8KONilEuERgEoQRaKblOy5KHRtfYXo606JDQPmj7CLG9uyYKT75kuqmzsFbKa9B5a9rKtqOltK006BHhJHh5"); // Replace with your publishable key

export default function StripeCheckout() {
  const [amount, setAmount] = useState(10);
  const [studentId, setStudentId] = useState("student123");
  const [courseId, setCourseId] = useState("course456");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleCheckout = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("http://localhost:5000/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount, studentId, courseId }),
      });

      const { id: sessionId } = await response.json();

      const stripe = await stripePromise;
      const { error } = await stripe.redirectToCheckout({ sessionId });

      if (error) {
        setError(error.message);
      }
    } catch (err) {
      setError("Failed to create checkout session");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Buy Course with Stripe</h2>

      <label style={styles.label}>
        Amount (USD):
        <input
          type="number"
          value={amount}
          min={1}
          onChange={(e) => setAmount(Number(e.target.value))}
          style={styles.input}
        />
      </label>

      <label style={styles.label}>
        Student ID:
        <input
          type="text"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
          style={styles.input}
        />
      </label>

      <label style={styles.label}>
        Course ID:
        <input
          type="text"
          value={courseId}
          onChange={(e) => setCourseId(e.target.value)}
          style={styles.input}
        />
      </label>

      <button onClick={handleCheckout} disabled={loading} style={styles.button}>
        {loading ? "Redirecting..." : "Pay with Stripe"}
      </button>

      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}

const styles = {
  container: {
    maxWidth: 400,
    margin: "auto",
    padding: 20,
    border: "1px solid #ddd",
    borderRadius: 8,
    marginTop: 50,
    fontFamily: "Arial, sans-serif",
  },
  label: {
    display: "block",
    marginBottom: 12,
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    padding: 8,
    marginTop: 4,
    fontSize: 16,
    borderRadius: 4,
    border: "1px solid #ccc",
  },
  button: {
    marginTop: 20,
    padding: "10px 20px",
    fontSize: 18,
    backgroundColor: "#6772e5",
    color: "white",
    border: "none",
    borderRadius: 4,
    cursor: "pointer",
  },
};

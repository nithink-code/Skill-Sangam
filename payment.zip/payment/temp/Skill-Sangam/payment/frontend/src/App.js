import React from "react";
import StripeCheckout from "./StripeCheckout";

function App() {
  return (
    <div>
      <StripeCheckout />
    </div>
  );
}

export default App;

# Skill-Sangam
24 Hour Hackathon Challenge
